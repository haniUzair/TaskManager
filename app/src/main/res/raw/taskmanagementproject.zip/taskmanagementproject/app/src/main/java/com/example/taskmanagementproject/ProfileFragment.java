package com.example.taskmanagementproject;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {
}
