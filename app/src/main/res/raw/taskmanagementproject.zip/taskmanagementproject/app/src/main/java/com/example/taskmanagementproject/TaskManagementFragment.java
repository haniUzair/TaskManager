package com.example.taskmanagementproject;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class TaskManagementFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_task_management, container, false);

        LinearLayout taskList = view.findViewById(R.id.task_list);

        for (int i = 1; i <= 8; i++) {
            View taskView = inflater.inflate(R.layout.task_item, null);
            TextView taskTitle = taskView.findViewById(R.id.task_title);
            TextView taskDescription = taskView.findViewById(R.id.task_description);
            CheckBox taskCheckbox = taskView.findViewById(R.id.task_checkbox);

            taskTitle.setText("Task " + i);
            if (i == 1) {
                taskTitle.setTextColor(getResources().getColor(R.color.green));
            }

            if (i == 1 || i == 6 || i == 7 || i == 8) {
                taskDescription.setText("Study for the test");
            } else {
                taskDescription.setText("Go to the gym");
            }

            taskCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    showSuccessScreen();
                } else {
                    // Handle checkbox unchecked state if needed
                }
            });

            taskList.addView(taskView);
        }

        return view;
    }

    private void showSuccessScreen() {
        Intent intent = new Intent(getContext(), SuccessActivity.class);
        startActivity(intent);
    }
}
